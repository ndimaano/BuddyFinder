//
//  BuddyFinderApp.swift
//  BuddyFinder
//
//  Created by Xichen Gao on 11/28/23.
//

import SwiftUI

@main
struct BuddyFinderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
